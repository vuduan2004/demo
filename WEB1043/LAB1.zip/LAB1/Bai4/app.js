let a = 10;
console.log("tuoi cua ban la " + a);
alert("so" + a);
var x = prompt("Input n: ");
document.write(x);